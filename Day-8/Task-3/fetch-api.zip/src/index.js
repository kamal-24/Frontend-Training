async function fetchUsers() {
  let info = fetch("https://jsonplaceholder.typicode.com/users")
    .then((response) => response.json())
    .then((result) => {
      return result;
    });
  try {
    let result = await info;
    console.log("Users: ", result);
  } catch (err) {
    console.log(err);
  }
}

fetchUsers();
